package Modelo;

import java.util.Scanner;

public class Sede {
    public String nameSede;
    String ubicacion;
    String ciudad;
    int nCuentas;
    int codigo;
    
    Scanner leer = new Scanner(System.in);
    int NoCuenta;
    String tipoCuenta;
    double saldoInicial;
    double saldo;

    public Sede(String nameSede, String ubicacion, String ciudad, int nCuentas, int codigo) {
        this.nameSede = nameSede;
        this.ubicacion = ubicacion;
        this.ciudad = ciudad;
        this.nCuentas = nCuentas;
        this.codigo = codigo;
    }

    public String getNameSede() {
        return nameSede;
    }

    public void setNameSede(String nameSede) {
        this.nameSede = nameSede;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public int getnCuentas() {
        return nCuentas;
    }

    public void setnCuentas(int nCuentas) {
        this.nCuentas = nCuentas;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Scanner getLeer() {
        return leer;
    }

    public void setLeer(Scanner leer) {
        this.leer = leer;
    }

    public int getNoCuenta() {
        return NoCuenta;
    }

    public void setNoCuenta(int NoCuenta) {
        this.NoCuenta = NoCuenta;
    }

    public String getTipoCuenta() {
        return tipoCuenta;
    }

    public void setTipoCuenta(String tipoCuenta) {
        this.tipoCuenta = tipoCuenta;
    }

    public double getSaldoInicial() {
        return saldoInicial;
    }

    public void setSaldoInicial(double saldoInicial) {
        this.saldoInicial = saldoInicial;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    


    public void nuevaCuenta(){
        System.out.println("No Cuenta: "); 
        NoCuenta = leer.nextInt();
        System.out.println("Tipo de cuenta [Corriente o Ahorros]: ");
        tipoCuenta = leer.nextLine();
        System.out.println("Saldo inicial: ");
        saldoInicial = leer.nextDouble();
    }
}
