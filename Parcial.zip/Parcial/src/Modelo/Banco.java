package Modelo;

import java.util.Scanner;

public class Banco {

    String name;
    int numSedes = 0;

    String nomSede, direccion, ubicacion;
    int noCuentas, codigo;

    Scanner leer = new Scanner(System.in);

    public Banco() {
    }

    public Banco(String name, int numSedes) {
        this.name = name;
        this.numSedes = numSedes;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
        System.out.println("Nombre del banco: ");
        name = leer.nextLine();
    }

    
    
    
    public int getNoSedes() {
        return numSedes;
    }

    public void setNoSedes(int NoSedes) {
        this.numSedes = NoSedes;
    }

    public void creacionSede() {
        System.out.println("--Nueva Sede--");
        System.out.println("Nombre de la Sede: ");
        nomSede = leer.nextLine();
        System.out.println("Direccion: ");
        direccion = leer.nextLine();
        System.out.println("Ciudad: ");
        ubicacion = leer.nextLine();
        noCuentas = 10;
        System.out.println("Codigo de Sede: ");
        codigo = leer.nextInt();
        numSedes += 1;
    }
}
