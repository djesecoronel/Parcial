package Modelo;

public class Cuentas {
    int numCuenta;
    String tpCuenta;
    double saldoInicial;
    double saldotot;

    public Cuentas(int numCuenta, String tpCuenta, double saldoInicial, double saldotot) {
        this.numCuenta = numCuenta;
        this.tpCuenta = tpCuenta;
        this.saldoInicial = saldoInicial;
        this.saldotot = saldotot;
    }

    public int getNumCuenta() {
        return numCuenta;
    }

    public void setNoCuenta(int numCuenta) {
        this.numCuenta = numCuenta;
    }

    public String getTpCuenta() {
        return tpCuenta;
    }

    public void setTpCuenta(String tpoCuenta) {
        this.tpCuenta = tpoCuenta;
    }

    public double getSaldoInicial() {
        return saldoInicial;
    }

    public void setSaldoInicial(double saldoInicial) {
        this.saldoInicial = saldoInicial;
    }

    public double getSaldotot() {
        return saldotot;
    }

    public void setSaldotot(double saldotot) {
        this.saldotot = saldotot;
    }
    
    
}
